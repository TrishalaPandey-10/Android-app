package com.example.justicequest

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LoginActivity : AppCompatActivity() {

    private val sharedPrefs by lazy { getSharedPreferences("users", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()
            val savedPassword = sharedPrefs.getString(username, null)

            if (savedPassword == null) {

                Toast.makeText(this, "No account found. Please sign up first.", Toast.LENGTH_SHORT).show()
            } else if (savedPassword == password) {

                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {

                Toast.makeText(this, "Incorrect password!", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnSignupPage).setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }

        findViewById<Button>(R.id.btnGuest).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}