package com.example.justicequest

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ChapterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chapter)

        val chapter = intent.getIntExtra("chapter", 1)
        val textView = findViewById<TextView>(R.id.chapterText)
        textView.text = when (chapter) {
            1 -> "Right to Education: Every child has the right to free and compulsory education between the ages of 6 and 14."
            2 -> "Right to Protection: Children must be protected from abuse, violence, and exploitation."
            3 -> "Right to Identity: Every child has the right to a name, nationality, and family ties."
            4 -> "Right to Health: Children have the right to access quality health services and live in a clean and safe environment."
            5 -> "Right to Nutrition: Every child has the right to proper nutrition to grow and thrive."
            6 -> "Right to Shelter: All children deserve a safe and secure place to live."
            7 -> "Right to Expression: Children have the freedom to express their thoughts and opinions."
            8 -> "Right to Participation: Children should be encouraged to take part in decisions that affect them."
            9 -> "Right to Play and Leisure: Every child has the right to rest, leisure, and engage in recreational activities."
            10 -> "Right to Equality: No child should face discrimination, regardless of gender, caste, religion, or background."
            11 -> "Right to Privacy: Every child has the right to keep their personal life and information private."
            12 -> "Right to Access Information: Children should have access to reliable information that helps them grow and develop."
            13 -> "Right to Reunification: If children are separated from their family, they have the right to reunite."
            14 -> "Right to Be Heard: Children’s views must be respected in all matters affecting them."
            15 -> "Right to Special Care for Disabled Children: Children with disabilities have the right to special care and education."
            16 -> "Right to Safety in Conflict: Even during wars or natural disasters, children must be kept safe."
            17 -> "Right to Legal Help: Children accused of breaking the law should receive legal support and fair treatment."
            18 -> "Right to Culture: Children have the right to practice and enjoy their own culture, language, and religion."
            19 -> "Right to Protection from Child Labour: Children should not be made to work in harmful or unfair conditions."
            20 -> "Right to Birth Registration: Every child should be registered at birth to ensure their identity and citizenship."
            else -> "Coming Soon"
        }
    }

    fun goBackToChapters(view: View) {
        val intent = Intent(this, LearnActivity::class.java)
        startActivity(intent)
        finish()
    }
}
