package com.example.justicequest

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class LearnActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_learn)

        val toolbar = findViewById<Toolbar>(R.id.learnToolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_quiz -> {
                startActivity(Intent(this, QuizListActivity::class.java))
                return true
            }
            R.id.action_logout -> {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    fun openChapter(view: View) {
        val chapterId = when (view.id) {
            R.id.btnChapter1 -> 1
            R.id.btnChapter2 -> 2
            R.id.btnChapter3 -> 3
            R.id.btnChapter4 -> 4
            R.id.btnChapter5 -> 5
            R.id.btnChapter6 -> 6
            R.id.btnChapter7 -> 7
            R.id.btnChapter8 -> 8
            R.id.btnChapter9 -> 9
            R.id.btnChapter10 -> 10
            R.id.btnChapter11 -> 11
            R.id.btnChapter12 -> 12
            R.id.btnChapter13 -> 13
            R.id.btnChapter14 -> 14
            R.id.btnChapter15 -> 15
            R.id.btnChapter16 -> 16
            R.id.btnChapter17 -> 17
            R.id.btnChapter18 -> 18
            R.id.btnChapter19 -> 19
            R.id.btnChapter20 -> 20
            else -> 1
        }
        val intent = Intent(this, ChapterActivity::class.java)
        intent.putExtra("chapter", chapterId)
        startActivity(intent)
    }
}
