package com.example.justicequest

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class QuizListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_list)

        val toolbar = findViewById<Toolbar>(R.id.quizListToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        findViewById<Button>(R.id.btnQuiz1).setOnClickListener { openQuiz(1) }
        findViewById<Button>(R.id.btnQuiz2).setOnClickListener { openQuiz(2) }
        findViewById<Button>(R.id.btnQuiz3).setOnClickListener { openQuiz(3) }
    }

    private fun openQuiz(quizId: Int) {
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra("quiz_id", quizId)
        startActivity(intent)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_logout -> {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                return true
            }
            R.id.action_learn -> {
                startActivity(Intent(this, LearnActivity::class.java))
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
