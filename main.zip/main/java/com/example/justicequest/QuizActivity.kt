package com.example.justicequest

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class QuizActivity : AppCompatActivity() {

    private var questions: List<Question> = listOf()
    private var currentQuestion = 0
    private var score = 0
    private lateinit var questionText: TextView
    private lateinit var optionsGroup: RadioGroup
    private lateinit var btnNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        val toolbar = findViewById<Toolbar>(R.id.quizToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Quiz"

        val quizId = intent.getIntExtra("quiz_id", 1)
        questions = loadQuestions(quizId)

        questionText = findViewById(R.id.questionText)
        optionsGroup = findViewById(R.id.optionsGroup)
        btnNext = findViewById(R.id.btnNext)

        loadQuestion()

        btnNext.setOnClickListener {
            val selectedId = optionsGroup.checkedRadioButtonId
            if (selectedId != -1) {
                val selectedIndex = optionsGroup.indexOfChild(findViewById(selectedId))
                if (selectedIndex == questions[currentQuestion].correctIndex) {
                    score++
                }
                currentQuestion++
                if (currentQuestion < questions.size) {
                    loadQuestion()
                } else {
                    showResult()
                }
            } else {
                Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadQuestions(quizId: Int): List<Question> {
        return when (quizId) {
            2 -> listOf(
                Question("Child helpline number is?", listOf("101", "102", "103", "1098"), 3),
                Question("POCSO deals with?", listOf("Abuse", "Education", "Police", "Traffic"), 0)
            )
            3 -> listOf(
                Question("Minimum working age in India?", listOf("12", "14", "16", "18"), 1),
                Question("Juvenile is someone under age?", listOf("18", "21", "16", "14"), 0)
            )
            else -> listOf(
                Question("What age group gets free education under RTE?", listOf("3–6", "6–14", "10–18", "All ages"), 1),
                Question("Which helpline number is for children?", listOf("100", "101", "1098", "112"), 2),
                Question("Which law protects children from abuse?", listOf("POCSO", "RTI", "RTE", "CRPC"), 0)
            )
        }
    }

    private fun loadQuestion() {
        val q = questions[currentQuestion]
        questionText.text = q.text
        optionsGroup.removeAllViews()
        q.options.forEach {
            val rb = RadioButton(this)
            rb.text = it
            optionsGroup.addView(rb)
        }
        optionsGroup.clearCheck()
    }

    private fun showResult() {
        AlertDialog.Builder(this)
            .setTitle("Quiz Finished")
            .setMessage("Your Score: $score / ${questions.size}")
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
            R.id.action_learn -> {
                startActivity(Intent(this, LearnActivity::class.java))
                return true
            }
            R.id.action_logout -> {
                Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    data class Question(val text: String, val options: List<String>, val correctIndex: Int)
}
